import streamlit as st
import requests

st.set_page_config(page_title="DRX-AI Dashboard", layout="wide")
st.title("DRX-AI Self-Healing Dashboard")

st.sidebar.header("Configuration")
api_key = st.sidebar.text_input("OpenAI API Key", type="password")
backend_url = st.sidebar.text_input("Backend URL", value="http://localhost:8000")

st.header("Playbook-Based Healing Simulation")
playbook_text = st.text_area("Paste your DR playbook here...", height=200)

if st.button("Run Self-Healing Simulation"):
    if not api_key or not playbook_text:
        st.error("API key and playbook are required.")
    else:
        with st.spinner("Sending to backend..."):
            files = {'file': ('playbook.txt', playbook_text)}
            parse_resp = requests.post(f"{backend_url}/parse-playbook/", files=files)
            scenario_resp = requests.post(f"{backend_url}/generate-scenarios/", files=files)
            
            if parse_resp.status_code == 200 and scenario_resp.status_code == 200:
                steps = parse_resp.json()["steps"]
                scenarios = scenario_resp.json()["scenarios"]
                st.success("Simulation completed!")

                st.subheader("Parsed Playbook Steps")
                for step in steps:
                    st.markdown(f"- Step {step['step_number']}: {step['description']}")

                st.subheader("Generated Disaster Scenarios")
                for scenario in scenarios:
                    st.markdown(f"**{scenario['failure']}** — {scenario['impact']}")

                st.markdown("---")
                st.info("Next step: Execute fixes or generate summaries via DRX-AI engine backend.")
            else:
                st.error("Backend error occurred during processing.")